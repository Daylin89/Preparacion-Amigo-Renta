package com.amigorenta.hugo;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Locale;
import java.util.Set;
import java.util.TimeZone;

/**
 * 🔔 Avisos en el teléfono (aunque la app esté cerrada): tareas de Operaciones, casas nuevas del plan y citas nuevas.
 *  - «Nueva tarea asignada» cuando alguien te asigna una tarea.
 *  - Recordatorios a la hora elegida (el mismo día 8 AM, el día antes, 1 hora antes, 30 min antes, a la hora).
 * Revisa el servidor cada ~15 minutos con la sesión (PIN) de quien entró en la app. Hora de Vancouver.
 */
public class Avisos extends BroadcastReceiver {
    static final String CH = "tareas", A_REM = "com.amigorenta.hugo.REM", A_POLL = "com.amigorenta.hugo.POLL";
    static final TimeZone TZ = TimeZone.getTimeZone("America/Vancouver");

    static SharedPreferences sp(Context c) { return c.getSharedPreferences("hugo", Context.MODE_PRIVATE); }

    // ---------------- sesión
    static void setAuth(Context c, String srv, String tok, String uid) {
        SharedPreferences.Editor e = sp(c).edit().putString("avSrv", srv == null ? "" : srv).putString("avTok", tok == null ? "" : tok);
        if (tok == null || tok.isEmpty()) { // salió: borrar recordatorios de esta persona
            cancelAll(c);
            e.putString("avUid", "").putString("avSeen", "[]").putBoolean("avInit", false);
        } else {
            if (!uid.equals(sp(c).getString("avUid", ""))) e.putString("avSeen", "[]").putBoolean("avInit", false).putLong("avSince", System.currentTimeMillis());
            e.putString("avUid", uid);
        }
        e.apply();
        if (tok != null && !tok.isEmpty()) schedulePoll(c);
    }

    static void schedulePoll(Context c) {
        try {
            Intent i = new Intent(c, Avisos.class).setAction(A_POLL);
            PendingIntent pi = PendingIntent.getBroadcast(c, 77, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            am.setInexactRepeating(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + AlarmManager.INTERVAL_FIFTEEN_MINUTES, AlarmManager.INTERVAL_FIFTEEN_MINUTES, pi);
        } catch (Exception ignored) { }
    }

    // ---------------- tareas → avisos y recordatorios
    /** Grupo de una lista: «h» = plan por casa y citas (ids h:… y a:…), «t» = tareas de Operaciones. */
    static String group(String id) { return id.startsWith("h:") || id.startsWith("a:") ? "h" : "t"; }

    /** tasks: tareas (objetos con id, title, date, time, remind[], status, who[], deleted, nt = título del aviso nuevo).
     *  scope: si no es null, la lista es completa para ese grupo (lo que no está, se cancela); null = solo cambios. */
    static synchronized void sync(Context c, JSONArray tasks, String scope) {
        boolean full = scope != null;
        try {
            String uid = sp(c).getString("avUid", "");
            if (uid.isEmpty()) return;
            Set<String> seen = new HashSet<>();
            JSONArray sa = new JSONArray(sp(c).getString("avSeen", "[]"));
            for (int i = 0; i < sa.length(); i++) seen.add(sa.getString(i));
            boolean init = sp(c).getBoolean("avInit", false);
            JSONObject rem = new JSONObject(sp(c).getString("avRem", "{}"));
            Set<String> live = new HashSet<>();
            long now = System.currentTimeMillis();
            for (int i = 0; i < tasks.length(); i++) {
                JSONObject t = tasks.getJSONObject(i);
                String id = t.optString("id");
                if (id.isEmpty()) continue;
                boolean mine = false;
                JSONArray w = t.optJSONArray("who");
                if (w != null) for (int j = 0; j < w.length(); j++) if (uid.equals(w.optString(j))) mine = true;
                boolean open = mine && !t.optBoolean("deleted") && !"completado".equals(t.optString("status"));
                cancelTask(c, rem, id);
                if (!open) continue;
                live.add(id);
                String title = t.optString("title", "Tarea"), when = whenTxt(t);
                if (!seen.contains(id)) {
                    seen.add(id);
                    if (init && !uid.equals(t.optString("createdBy"))) notify(c, ("t" + id).hashCode(), t.optString("nt", "📌 Nueva tarea asignada"), title + (when.isEmpty() ? "" : " · " + when), id);
                }
                JSONArray r = t.optJSONArray("remind");
                if (r == null) continue;
                Set<Long> used = new HashSet<>();
                for (int j = 0; j < r.length(); j++) {
                    long at = remindAt(t, r.optString(j));
                    if (at <= now || used.contains(at)) continue;
                    used.add(at);
                    String key = id + "|" + r.optString(j);
                    String txt = title + (when.isEmpty() ? "" : " · " + when) + (t.optString("property").isEmpty() ? "" : " · " + t.optString("property"));
                    String rt = id.startsWith("a:") ? "⏰ Recordatorio de cita" : id.startsWith("h:") ? "⏰ Recordatorio del plan" : "⏰ Recordatorio de tarea";
                    rem.put(key, new JSONArray().put(at).put(rt).put(txt).put(id));
                    setAlarm(c, key, at, rt, txt, id);
                }
            }
            if (full) { // lo que ya no está en la lista: fuera
                for (Iterator<String> it = rem.keys(); it.hasNext(); ) {
                    String k = it.next();
                    String kid = k.split("\\|")[0];
                    if (group(kid).equals(scope) && !live.contains(kid)) { cancelAlarm(c, k); it.remove(); }
                }
            }
            JSONArray so = new JSONArray();
            for (String s : seen) so.put(s);
            sp(c).edit().putString("avSeen", so.toString()).putString("avRem", rem.toString()).putBoolean("avInit", true).apply();
        } catch (Exception ignored) { }
    }

    static void cancelTask(Context c, JSONObject rem, String id) {
        for (Iterator<String> it = rem.keys(); it.hasNext(); ) {
            String k = it.next();
            if (k.startsWith(id + "|")) { cancelAlarm(c, k); it.remove(); }
        }
    }

    static void cancelAll(Context c) {
        try {
            JSONObject rem = new JSONObject(sp(c).getString("avRem", "{}"));
            for (Iterator<String> it = rem.keys(); it.hasNext(); ) cancelAlarm(c, it.next());
            sp(c).edit().putString("avRem", "{}").apply();
        } catch (Exception ignored) { }
    }

    static String whenTxt(JSONObject t) {
        String d = t.optString("date"), h = t.optString("time");
        if (d.length() < 10) return "";
        try {
            SimpleDateFormat in = new SimpleDateFormat("yyyy-MM-dd", Locale.US), out = new SimpleDateFormat("EEE d MMM", new Locale("es"));
            in.setTimeZone(TZ); out.setTimeZone(TZ);
            String s = out.format(in.parse(d));
            if (h.length() >= 5) {
                int hh = Integer.parseInt(h.substring(0, 2)), mm = Integer.parseInt(h.substring(3, 5));
                s += " " + ((hh + 11) % 12 + 1) + ":" + String.format(Locale.US, "%02d", mm) + (hh < 12 ? " AM" : " PM");
            }
            return s;
        } catch (Exception e) { return d; }
    }

    /** Momento del recordatorio, en hora de Vancouver. */
    static long remindAt(JSONObject t, String r) {
        try {
            String d = t.optString("date"), h = t.optString("time");
            if (d.length() < 10) return 0;
            boolean hasTime = h.length() >= 5;
            SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US);
            f.setTimeZone(TZ);
            long base = f.parse(d + " " + (hasTime ? h.substring(0, 5) : "08:00")).getTime(), day8 = f.parse(d + " 08:00").getTime();
            switch (r) {
                case "dia": return day8;
                case "d1": return hasTime ? base - 86400000L : f.parse(d + " 08:00").getTime() - 14 * 3600000L; // el día antes (6 PM si no tiene hora)
                case "h1": return hasTime ? base - 3600000L : 0;
                case "m30": return hasTime ? base - 1800000L : 0;
                case "at": return base;
                default: return 0;
            }
        } catch (Exception e) { return 0; }
    }

    static PendingIntent remPI(Context c, String key, String title, String text, String id, int flag) {
        Intent i = new Intent(c, Avisos.class).setAction(A_REM).putExtra("key", key).putExtra("title", title).putExtra("text", text).putExtra("id", id);
        return PendingIntent.getBroadcast(c, key.hashCode(), i, flag | PendingIntent.FLAG_IMMUTABLE);
    }

    static void setAlarm(Context c, String key, long at, String title, String text, String id) {
        try {
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, remPI(c, key, title, text, id, PendingIntent.FLAG_UPDATE_CURRENT));
        } catch (Exception ignored) { }
    }

    static void cancelAlarm(Context c, String key) {
        try {
            PendingIntent pi = remPI(c, key, "", "", "", PendingIntent.FLAG_NO_CREATE);
            if (pi != null) { ((AlarmManager) c.getSystemService(Context.ALARM_SERVICE)).cancel(pi); pi.cancel(); }
        } catch (Exception ignored) { }
    }

    // ---------------- notificación
    static void notify(Context c, int nid, String title, String text, String taskId) {
        try {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel(CH) == null) {
                NotificationChannel ch = new NotificationChannel(CH, "Tareas y recordatorios", NotificationManager.IMPORTANCE_HIGH);
                ch.setDescription("Tareas nuevas asignadas y recordatorios");
                nm.createNotificationChannel(ch);
            }
            Intent open = new Intent(c, MainActivity.class).putExtra("task", taskId == null ? "" : taskId).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            PendingIntent pi = PendingIntent.getActivity(c, nid, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c, CH) : new Notification.Builder(c);
            b.setSmallIcon(android.R.drawable.ic_popup_reminder).setContentTitle(title).setContentText(text)
                    .setStyle(new Notification.BigTextStyle().bigText(text)).setAutoCancel(true).setContentIntent(pi);
            if (Build.VERSION.SDK_INT < 26) b.setPriority(Notification.PRIORITY_HIGH).setDefaults(Notification.DEFAULT_ALL);
            nm.notify(nid, b.build());
        } catch (Exception ignored) { }
    }

    // ---------------- revisar el servidor (app cerrada)
    static void poll(Context c) {
        try {
            String srv = sp(c).getString("avSrv", ""), tok = sp(c).getString("avTok", "");
            if (srv.isEmpty() || tok.isEmpty()) return;
            long since = sp(c).getLong("avSince", System.currentTimeMillis());
            HttpURLConnection h = (HttpURLConnection) new URL(srv + "/api/o/changes?since=" + Math.max(0, since - 120000)).openConnection();
            h.setConnectTimeout(15000);
            h.setReadTimeout(25000);
            h.setRequestProperty("X-O-Token", tok);
            int code = h.getResponseCode();
            if (code != 200) { h.disconnect(); return; }
            byte[] buf = new byte[16384];
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            try (InputStream in = h.getInputStream()) { int n; while ((n = in.read(buf)) > 0) bo.write(buf, 0, n); }
            h.disconnect();
            JSONObject j = new JSONObject(new String(bo.toByteArray(), StandardCharsets.UTF_8));
            JSONArray recs = j.optJSONArray("records"), ts = new JSONArray();
            if (recs != null) for (int i = 0; i < recs.length(); i++) {
                JSONObject r = recs.getJSONObject(i);
                if (!"ot".equals(r.optString("kind"))) continue;
                JSONObject d = r.optJSONObject("data");
                if (d == null) continue;
                d.put("id", r.optString("id"));
                if (d.optString("title").isEmpty()) d.put("title", "Tarea");
                ts.put(d);
            }
            sync(c, ts, null);
            pollPrep(c, srv, tok);
            sp(c).edit().putLong("avSince", j.optLong("now", System.currentTimeMillis())).apply();
        } catch (Exception ignored) { }
    }

    /** Plan por casa y citas (app cerrada): pide todo lo de Hugo y avisa lo nuevo. */
    static void pollPrep(Context c, String srv, String tok) {
        try {
            HttpURLConnection h = (HttpURLConnection) new URL(srv + "/api/o/h/changes").openConnection();
            h.setConnectTimeout(15000);
            h.setReadTimeout(25000);
            h.setRequestProperty("X-O-Token", tok);
            if (h.getResponseCode() != 200) { h.disconnect(); return; }
            byte[] buf = new byte[16384];
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            try (InputStream in = h.getInputStream()) { int n; while ((n = in.read(buf)) > 0) bo.write(buf, 0, n); }
            h.disconnect();
            JSONObject j = new JSONObject(new String(bo.toByteArray(), StandardCharsets.UTF_8));
            String uid = sp(c).getString("avUid", ""), today = j.optString("today");
            JSONArray recs = j.optJSONArray("records"), ts = new JSONArray();
            if (recs != null) for (int i = 0; i < recs.length(); i++) {
                JSONObject r = recs.getJSONObject(i), d = r.optJSONObject("data");
                if (d == null) continue;
                String k = r.optString("kind"), id = r.optString("id");
                JSONObject t = new JSONObject();
                if ("hcas".equals(k)) {
                    if (d.optBoolean("deleted") || d.optBoolean("archived") || (!d.optString("who").isEmpty() && !d.optString("who").equals(uid))) continue;
                    String room = d.optString("room"), title = d.optString("title");
                    t.put("id", "h:" + id).put("title", "🏠 " + d.optString("house") + (room.isEmpty() ? "" : " · " + room) + (title.isEmpty() ? "" : " — " + title))
                            .put("date", d.optString("date")).put("time", d.optString("time")).put("createdBy", d.optString("createdBy")).put("nt", "🧰 Nuevo en tu plan")
                            .put("status", "listo".equals(d.optString("status")) ? "completado" : "");
                    JSONArray rm = new JSONArray();
                    if (!d.optString("date").isEmpty()) { rm.put("dia"); if (!d.optString("time").isEmpty()) rm.put("h1"); }
                    t.put("remind", rm);
                } else if ("appt".equals(k)) {
                    String st = d.optString("status");
                    if (!("Programada".equals(st) || "Confirmada".equals(st)) || d.optString("date").compareTo(today) < 0) continue;
                    String addr = d.optString("address");
                    t.put("id", "a:" + id).put("title", "📅 " + d.optString("time") + " · " + d.optString("name") + (addr.isEmpty() ? "" : " · " + addr))
                            .put("date", d.optString("date")).put("time", d.optString("time")).put("createdBy", "").put("nt", "📅 Nueva cita")
                            .put("remind", new JSONArray().put("dia").put("h1").put("m30"));
                } else continue;
                t.put("who", new JSONArray().put(uid));
                ts.put(t);
            }
            sync(c, ts, "h");
        } catch (Exception ignored) { }
    }

    @Override
    public void onReceive(Context c, Intent i) {
        String a = i.getAction() == null ? "" : i.getAction();
        if (A_REM.equals(a)) {
            String key = i.getStringExtra("key");
            try {
                JSONObject rem = new JSONObject(sp(c).getString("avRem", "{}"));
                if (key == null || !rem.has(key)) return; // la tarea se completó o cambió
                rem.remove(key);
                sp(c).edit().putString("avRem", rem.toString()).apply();
            } catch (Exception ignored) { }
            notify(c, key.hashCode(), i.getStringExtra("title"), i.getStringExtra("text"), i.getStringExtra("id"));
        } else if (A_POLL.equals(a)) {
            final PendingResult pr = goAsync();
            new Thread(() -> { try { poll(c); } finally { pr.finish(); } }).start();
        } else if (Intent.ACTION_BOOT_COMPLETED.equals(a) || "android.intent.action.MY_PACKAGE_REPLACED".equals(a)) {
            try { // las alarmas se borran al reiniciar el teléfono: volver a ponerlas
                JSONObject rem = new JSONObject(sp(c).getString("avRem", "{}"));
                long now = System.currentTimeMillis();
                for (Iterator<String> it = rem.keys(); it.hasNext(); ) {
                    String k = it.next();
                    JSONArray v = rem.getJSONArray(k);
                    if (v.getLong(0) > now) setAlarm(c, k, v.getLong(0), v.getString(1), v.getString(2), v.optString(3));
                }
            } catch (Exception ignored) { }
            if (!sp(c).getString("avTok", "").isEmpty()) schedulePoll(c);
        }
    }
}
