# Preparación Amigo Renta (app de Hugo) — Android v1.0

Abre la página /h del servidor amigorentacliente con el nombre y PIN de la App Operativa (permiso «🧰 App de Preparación y Citas»):
Hoy (antes de salir + chuletas + suministros), Citas (cita lista, acceso, quién muestra, resultado), Casas (plan por casa y cuarto,
pasos, listo / pendiente, cierre por unidad, fotos), Accesos (llaves: OK, FALTA, TEMP., PERDIDA). Desde «Más» abre Operaciones
(tareas, ruta de cobranza, metas). Avisos en el teléfono: casas nuevas del plan, citas nuevas y recordatorios.
Se compila con GitHub Actions (.github/workflows/compilar-apk.yml).
